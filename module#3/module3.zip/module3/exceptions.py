class EnemyDown(Exception):
    pass


class GameOver(Exception):
    # def write(self, player_obj):
    #     f = open("scores.txt", "w")
    #     f.write("Счет игрока " + player_obj.name + " - " + player_obj.score + "\n")
    #     f.close()
    pass


class Score:
    pass