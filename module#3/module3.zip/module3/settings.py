class Const:
    heal = 3