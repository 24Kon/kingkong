from typing import AbstractSet
from django.db import models, transaction
from django.contrib.auth.models import AbstractUser
from django.db.models.deletion import CASCADE, DO_NOTHING
from django.db.models.fields import BooleanField, CharField, DateTimeField, PositiveIntegerField, TextField
from django.db.models.fields.files import ImageField
from django.db.models.fields.related import ForeignKey
from django.utils import timezone
from close.exceptions import NotMuchCount, NotMuchMoney, NotZeroCount, TimeOut


class MyUser(AbstractUser):
    wallet = models.PositiveIntegerField(blank=True, null=True)

    def __str__(self):
        return self.username


class ProductModel(models.Model):
    name = TextField(max_length=50, blank=False, null=False)
    desc = CharField(max_length=50, blank=False, null=False)
    price = PositiveIntegerField(blank=False, null=False)
    amount = PositiveIntegerField(blank=False, null=False)
    image = ImageField(blank=True, null=True)

    class Meta:
        ordering = ["price"]

    def __str__(self):
        return self.name


class PurchaseModel(models.Model):
    product = ForeignKey(ProductModel, on_delete=DO_NOTHING, related_name="purchases")
    user = ForeignKey(MyUser, on_delete=DO_NOTHING, related_name="user")
    amount_purchase = PositiveIntegerField(blank=False, null=False)
    create_time = DateTimeField(auto_now=True),
    return_status = BooleanField(default=False),
    status = BooleanField(default=False)

    class Meta:
        ordering = ["product"]

    def __str__(self):
        return self.product

    
    def save(self, *args, **kwargs):
        user = self.user
        money = self.user.wallet
        product = self.product
        amount_purchase = self.amount_purchase
        if product.amount >= amount_purchase != 0 and money > (amount_purchase * product.price):
            money -= (amount_purchase * product.price)
            product.amount -= amount_purchase
            with transaction.atomic():
                user.save()
                product.save()
                super(PurchaseModel, self).save(*args, **kwargs)
        elif money < (amount_purchase * product.price):
            raise NotMuchMoney
        elif product.amount < amount_purchase:
            raise NotMuchCount
        elif amount_purchase == 0:
            raise NotZeroCount
        


class ReturnModel(models.Model):
    purchase = ForeignKey(PurchaseModel, on_delete=CASCADE, related_name="returns")
    time_request = DateTimeField(auto_now=True)

    class Meta:
        ordering = ["time_request"]
    
    def __str__(self):
        return self.purchase

    def save(self, *args, **kwargs):
        purchase = self.purchase
        money = self.user.wallet
        product = self.product
        amount_purchase = self.amount_purchase
        if (timezone.now - purchase.create_time).seconds < 180:
            purchase.status = True
            product.amount += amount_purchase
            money += product.price
            with transaction.atomic():
                purchase.save()
                super(ReturnModel, self).save(*args, **kwargs)
        else:
            raise TimeOut

