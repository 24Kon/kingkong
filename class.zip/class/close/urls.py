from django.contrib.auth.views import LoginView
from django.urls import path
from close.views import Login, ProductListView, Profile, Register


urlpatterns = [
    path('productlist/', ProductListView.as_view(), name='productlist'), 
    path('login/', Login.as_view(), name='login'), 
    path('register/', Register.as_view(), name='register'),
    path('profile/', Profile.as_view(), name='profile')
]   