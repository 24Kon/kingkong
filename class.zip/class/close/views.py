from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import LoginView, LogoutView
from django.views.generic import ListView, CreateView
from django.urls import reverse_lazy
from django.views.generic.base import TemplateView
from close.forms import RegisterForm
from close.models import ProductModel



class ProductListView(ListView):
    model = ProductModel
    template_name = 'product_list.html'
    login_url = 'login/'


class Login(LoginView):
    success_url = reverse_lazy('profile')
    template_name = 'login.html'


class Register(CreateView):
    form_class = RegisterForm
    template_name = 'register.html'
    success_url = reverse_lazy('profile')


class Logout(LoginRequiredMixin, LogoutView):
    next_page = reverse_lazy('login')
    login_url = 'login/'


class Profile(TemplateView):
    template_name = 'profile.html'
    
