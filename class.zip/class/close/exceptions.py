class NotMuchMoney(ValueError):
    pass


class NotMuchCount(ValueError):
    pass


class NotZeroCount(ValueError):
    pass


class TimeOut(ValueError):
    pass